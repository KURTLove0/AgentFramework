---
name: release-evidence-review
description: 评估模拟发布变更时复核证据并生成草稿。用于模拟变更风险评审与报告复核。
license: MIT
metadata:
  author: "synthetic-demo"
  version: "1.0.0"
---

# 模拟发布证据复核

在编写评估报告前，读取 [报告约定](references/report.md)，按该约定组织标题。评估仍依据可信工具证据和岗位标准，写入需要独立授权。
