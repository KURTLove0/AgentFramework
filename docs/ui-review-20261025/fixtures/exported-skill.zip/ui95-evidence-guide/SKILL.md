---
name: ui95-evidence-guide
description: "说明此技能的用途，以及应在何时使用。"
---

# 使用方法

填写能改善 Agent 工作方式的指导。将详细资料放入 references/，并在需要时通过相对路径引用。
---
name: ui95-evidence-guide
description: 核对变更资料来源并记录可追溯证据。
---

# 使用方法
先读取来源，再检查结论是否有证据。