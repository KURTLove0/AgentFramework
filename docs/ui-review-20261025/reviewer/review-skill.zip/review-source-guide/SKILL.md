---
name: review-source-guide
description: "说明此技能的用途，以及应在何时使用。"
---

# 使用方法

填写能改善 Agent 工作方式的指导。将详细资料放入 references/，并在需要时通过相对路径引用。
---
name: review-source-guide
description: 核对资料来源与引用范围。
---

# 核对方法
逐条核对来源是否支持结论。